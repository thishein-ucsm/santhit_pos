-- MySQL dump 10.13  Distrib 8.0.35, for Win64 (x86_64)
--
-- Host: localhost    Database: santhitdb
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `buy`
--

DROP TABLE IF EXISTS `buy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `buy` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` varchar(45) NOT NULL,
  `buyid` varchar(45) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(300) NOT NULL,
  `category` varchar(50) NOT NULL,
  `cost` varchar(50) NOT NULL,
  `quantity` varchar(45) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `date` varchar(50) NOT NULL,
  `expdate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buy`
--

LOCK TABLES `buy` WRITE;
/*!40000 ALTER TABLE `buy` DISABLE KEYS */;
INSERT INTO `buy` VALUES (2,'diap-02 ','buyid-0002','Baby Ken M','Baby Ken Medium M size','Baby Diaper','3000','100','ChocolateBaby','29/01/2024','29/01/2026'),(3,'T0001 ','buyid-0003','Rose','Rose Tissue','Tissue','120','100','U San Thit','29/01/2024','29/01/2026'),(4,'T0001','buyid-0004','Rose','Rose Tissue','Tissue','120','50','U San Thit','29/01/2024','29/01/2026'),(5,'tis-0002','buyid-0005','shwe','shwe tissue','Tissue','800','30','ChocolateBaby','29/01/2024','29/01/2026'),(6,'tis-0002','buyid-0006','shwe','shwe tissue','Tissue','800','100','ChocolateBaby','29/01/2024','29/01/2025'),(7,'tis-0002','buyid-0007','shwe','shwe tissue','Tissue','800','100','ChocolateBaby','29/01/2024','29/01/2025'),(8,'diap-02','buyid-0008','Baby Ken M','Baby Ken Medium M size','Baby Diaper','3000','100','ChocolateBaby','29/01/2024','29/01/2026'),(9,'diap-02','buyid-0009','Baby Ken M','Baby Ken Medium M size','Baby Diaper','3000','100','ChocolateBaby','29/01/2024','29/01/2027');
/*!40000 ALTER TABLE `buy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `catid` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'TIS','Tissue'),(2,'TP','ToothPaste'),(3,'DT','Detergent'),(5,'Kidware01','Baby Diaper');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cusid` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `custype` varchar(50) NOT NULL,
  `address` varchar(500) DEFAULT '**data required**',
  `remark` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `id` int NOT NULL AUTO_INCREMENT,
  `empid` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `dob` varchar(45) DEFAULT '**data required**',
  `nrc` varchar(30) DEFAULT '**data required**',
  `gender` varchar(15) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `salary` varchar(10) NOT NULL,
  `usertype` varchar(45) NOT NULL,
  `address` varchar(500) DEFAULT '**data required**',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` varchar(500) NOT NULL,
  `qty` varchar(100) DEFAULT 'n/a',
  `price` varchar(100) DEFAULT 'n/a',
  `sprice` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'active',
  `category` varchar(100) NOT NULL,
  `supplier` varchar(100) DEFAULT '**data required**',
  `created_time` varchar(30) DEFAULT '**data required**',
  `remark` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'T0001','Rose','Rose Tissue','147','11700','150','Active','Tissue','U San Thit','18/10/2023','87738'),(2,'diap-01','Baby Ken','Baby Ken Regular Size-S','63','6000','6800','Active','Baby Diaper','ChocolateBaby','16/01/2024','-'),(3,'tis-0002','shwe','shwe tissue','314','600','1000','Active','Tissue','ChocolateBaby','28/01/2024','-'),(4,'diap-02','Baby Ken M','Baby Ken Medium M size','194','3000','3400','Active','Baby Diaper','ChocolateBaby','29/01/2024','inv-0000'),(5,'diap-03','Baby Ken L','Baby Ken Medium L size','0','3000','3400','Active','Baby Diaper','ChocolateBaby','29/01/2024','inv-0000');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saleorder`
--

DROP TABLE IF EXISTS `saleorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saleorder` (
  `sr` int NOT NULL AUTO_INCREMENT,
  `date` varchar(45) NOT NULL,
  `voucherid` varchar(45) NOT NULL,
  `cid` varchar(45) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `pid` varchar(45) NOT NULL,
  `qty` varchar(45) NOT NULL,
  `total` varchar(45) NOT NULL,
  PRIMARY KEY (`sr`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saleorder`
--

LOCK TABLES `saleorder` WRITE;
/*!40000 ALTER TABLE `saleorder` DISABLE KEYS */;
INSERT INTO `saleorder` VALUES (1,'17012024','17227436','custID','Customer','diap-01','5','ammmt'),(2,'17012024','17227550','custID','Customer','diap-01','5','ammmt'),(3,'27012024','27244577','custID','Customer','T0001','1','ammmt'),(4,'27012024','27244635','custID','Customer','T0001','1','ammmt'),(5,'27012024','27244670','custID','Customer','T0001','1','ammmt'),(6,'27012024','27244675','custID','Customer','diap-01','1','ammmt'),(7,'27012024','27245154','custID','Customer','diap-01','10','ammmt'),(8,'27012024','27245247','custID','Customer','diap-01','5','ammmt'),(9,'27012024','27247479','custID','Customer','diap-01','10','ammmt'),(10,'27012024','27247632','custID','Customer','diap-01','1','ammmt'),(11,'27012024','27247667','custID','Customer','diap-01','1','ammmt'),(12,'27012024','27247968','custID','Customer','diap-01','1','ammmt'),(13,'28012024','28012057','custID','Customer','diap-01','1','ammmt'),(14,'28012024','28012351','custID','Customer','diap-01','1','ammmt'),(15,'28012024','28012363','custID','Customer','T0001','1','ammmt'),(16,'28012024','28012377','custID','Customer','diap-01','1','ammmt'),(17,'28012024','28015634','custID','Customer','tis-0002','aa','ammmt'),(18,'29012024','204201/290124','custID','CustName','diap-01','6','40800'),(19,'29012024','204511/290124','custID','CustName','diap-01','5','34000'),(20,'29012024','204646_290124','custID','CustName','diap-01','1','6800'),(21,'29012024','205137_290124','custID','CustName','diap-01','5','34000'),(22,'29012024','205341_290124','custID','CustName','diap-01','8','54400'),(23,'29012024','205434_290124','custID','CustName','diap-01','12','81600'),(24,'29-01-24','205916_290124','custID','CustName','diap-01','2','13600'),(25,'29-01-24','215931_290124','custID','CustName','diap-01','8','54400'),(26,'29-01-24','220114_290124','custID','CustName','diap-01','2','13600'),(27,'29-01-24','220247_290124','custID','CustName','diap-01','11','74800'),(28,'29-01-24','220705_290124','custID','CustName','diap-01','5','34000'),(29,'29-01-24','220847_290124','custID','CustName','diap-01','2','13600'),(30,'29-01-24','220929_290124','custID','CustName','diap-01','3','20400'),(31,'29-01-24','222033_290124','custID','CustName','diap-01','5','34000'),(32,'29-01-24','222033_290124','custID','CustName','tis-0002','6','6000'),(33,'29-01-24','234305_290124','custID','CustName','diap-01','10','68000'),(34,'29-01-24','234652_290124','custID','CustName','diap-01','5','34000'),(35,'29-01-24','234759_290124','custID','CustName','diap-01','5','34000'),(36,'29-01-24','234759_290124','custID','CustName','diap-02','6','20400'),(37,'29-01-24','234759_290124','custID','CustName','T0001','3','450'),(38,'29-01-24','234759_290124','custID','CustName','tis-0002','10','10000'),(39,'29-01-24','235006_290124','custID','CustName','diap-01','1','6800'),(40,'29-01-24','235057_290124','custID','CustName','diap-01','1','6800');
/*!40000 ALTER TABLE `saleorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supid` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `companyName` varchar(500) NOT NULL,
  `companyPhone` varchar(50) NOT NULL,
  `address` varchar(500) DEFAULT '**data required**',
  `remark` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'SP001','U San Thit','ZayCho','ZayCho','09-7777777','ZayCho\n','ZayCho'),(2,'SP002','ChocolateBaby','09','ChocolateBaby','09','yangon\n','Diaper Wholesale');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT '**data required**',
  `status` varchar(45) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `created_time` varchar(30) DEFAULT '**data required**',
  `usertype` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'u-0001','kyawswewin','admin','admin123','kgmobile.service@gmail.com','Active','12.1.2024','Admin');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallet`
--

DROP TABLE IF EXISTS `wallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `walid` varchar(45) NOT NULL,
  `description` varchar(200) NOT NULL,
  `deposit` varchar(50) NOT NULL,
  `withdraw` varchar(50) NOT NULL,
  `balance` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet`
--

LOCK TABLES `wallet` WRITE;
/*!40000 ALTER TABLE `wallet` DISABLE KEYS */;
INSERT INTO `wallet` VALUES (1,'walid-0001','buyid-0007','0','80000','-80000','29/01/2024'),(2,'walid-0002','buyid-0008','0','300000','-380000','29/01/2024'),(3,'walid-0003','buyid-0009','0','300000','-680000','29/01/2024');
/*!40000 ALTER TABLE `wallet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-30  6:51:13
